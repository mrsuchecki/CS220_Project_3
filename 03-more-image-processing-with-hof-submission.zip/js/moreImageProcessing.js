function weightedPixel(img, x, y, neighborOffsets, neighborWeight, centerWeight) {
    let r = 0;
    let g = 0;
    let b = 0;
    for (const dx of neighborOffsets) {
        const nx = x + dx;
        const ny = y;
        if (nx >= 0 && nx < img.width - 1 && ny >= 0 && ny < img.height - 1) {
            const neighborPixel = img.getPixel(nx, ny);
            r += neighborWeight * neighborPixel[0];
            g += neighborWeight * neighborPixel[1];
            b += neighborWeight * neighborPixel[2];
        }
    }
    const centerPixel = img.getPixel(x, y);
    r += centerWeight * centerPixel[0];
    g += centerWeight * centerPixel[1];
    b += centerWeight * centerPixel[2];
    return [Math.trunc(r), Math.trunc(g), Math.trunc(b)];
}
function computeCenterWeight(neighborOffsets, neighborWeight) {
    return 1 - (neighborOffsets.length - 1) * neighborWeight;
}
export function lineBlur3p(img, lineNo) {
    const neighborOffsets = [-1, 0, 1];
    const neighborWeight = 1 / 3;
    const centerWeight = computeCenterWeight(neighborOffsets, neighborWeight);
    if (lineNo < 0 || lineNo >= img.height) {
        return;
    }
    for (let x = 0; x < img.width; ++x) {
        const pixel = weightedPixel(img, x, lineNo, neighborOffsets, neighborWeight, centerWeight);
        img.setPixel(x, lineNo, pixel);
    }
}
export function lineBlur5p(img, lineNo) {
    const neighborOffsets = [-2, -1, 0, 1, 2];
    const neighborWeight = 1 / 5;
    const centerWeight = computeCenterWeight(neighborOffsets, neighborWeight);
    if (lineNo < 0 || lineNo >= img.height) {
        return;
    }
    for (let x = 0; x < img.width; ++x) {
        const pixel = weightedPixel(img, x, lineNo, neighborOffsets, neighborWeight, centerWeight);
        img.setPixel(x, lineNo, pixel);
    }
}
export function blurLines(img, blurLine) {
    //   const newImg = img.copy();
    //   for (let y = 0; y < img.height; y++) {
    //     // Create a copy of the line
    //     const lineCopy = new Image(img.width, 1);
    //     for (let x = 0; x < img.width; x++) {
    //       lineCopy.setPixel(x, 0, img.getPixel(x, y));
    //     }
    //     // Apply the blurLine function to the line copy
    //     blurLine(lineCopy, y);
    //     // Copy the blurred line back to the new image
    //     for (let x = 0; x < img.width; x++) {
    //       newImg.setPixel(x, y, lineCopy.getPixel(x, 0));
    //     }
    //   }
    //   return newImg;
    return img;
}
export function pixelBlur(img, x, y) {
    const neighbors = [];
    for (let i = -1; i <= 1; ++i) {
        for (let j = -1; j <= 1; ++j) {
            const nx = x + i;
            const ny = y + j;
            if (nx >= 0 && nx < img.width && ny >= 0 && ny < img.height) {
                neighbors.push(img.getPixel(nx, ny));
            }
        }
    }
    const red = Math.trunc(neighbors.reduce((sum, pixel) => sum + pixel[0], 0) / neighbors.length);
    const green = Math.trunc(neighbors.reduce((sum, pixel) => sum + pixel[1], 0) / neighbors.length);
    const blue = Math.trunc(neighbors.reduce((sum, pixel) => sum + pixel[2], 0) / neighbors.length);
    return [red, green, blue];
}
function imageMapCoord(img, func) {
    const newImg = img.copy();
    for (let i = 0; i < newImg.width; ++i) {
        for (let j = 0; j < newImg.height; ++j) {
            newImg.setPixel(i, j, func(img, i, j));
        }
    }
    return newImg;
}
export function imageBlur(img) {
    const blurFunc = (img, x, y) => pixelBlur(img, x, y);
    return imageMapCoord(img, blurFunc);
}
export function composeFunctions(fa) {
    return fa.reduce((acc, f) => x => f(acc(x)), x => x);
}
export function imageMap(img, func) {
    let newImg = img.copy();
    for (let i = 0; i < newImg.width; ++i) {
        for (let j = 0; j < newImg.height; ++j) {
            let pixel = newImg.getPixel(i, j);
            newImg.setPixel(i, j, func(pixel));
        }
    }
    return newImg;
}
export function removeRed(color) {
    return [0, color[1], color[2]];
}
export function flipColors(color) {
    const flipRed = Math.floor((color[1] + color[2]) / 2);
    const flipGreen = Math.floor((color[0] + color[2]) / 2);
    const flipBlue = Math.floor((color[0] + color[1]) / 2);
    return [flipRed, flipGreen, flipBlue];
}
export function combineThree(img) {
    const transform = composeFunctions([removeRed, flipColors, flipColors]);
    return imageMap(img, transform);
}
//# sourceMappingURL=moreImageProcessing.js.map